package projetolivro;

public class Pessoa {
    private String nome;
    private String sexo;
    private int idade;
    
    public Pessoa(String Nome,String Sexo,int Idade){
        this.setNome(Nome);
        this.setSexo(Sexo);
        this.setIdade(Idade);
    }
    
    public void informacoes(){
        System.out.println("======Ficha======");
        System.out.println("Nome: "+this.getNome());
        System.out.println("Sexo: "+this.getSexo());
        System.out.println("Idade: "+this.getIdade());
    }
    public void fazerAniversario(){
        this.setIdade(this.getIdade()+1);
    }
    
    public void setNome(String n){
        this.nome = n;
    }
    public String getNome(){
        return nome;
    }
    
    public void setSexo(String s){
        this.sexo = s;
    }
    public String getSexo(){
        return sexo;
    }
    
    public void setIdade(int i){
        this.idade = i;
    }
    
    public int getIdade(){
        return idade;
    }
    
}
