package projetolivro;

public class ProjetoLivro {

    public static void main(String[] args) {
    Pessoa p1 = new Pessoa("Douglas","masculino",19);
    p1.informacoes();
    Livro L1 = new Livro("A culpa é das estrelas", "John Green",
    255, 0,p1);
    L1.abrir();
    L1.folhear(257);
    L1.detalhes();
    }

    
    
}
