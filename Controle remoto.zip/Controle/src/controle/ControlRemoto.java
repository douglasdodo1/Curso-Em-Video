package controle;

public class ControlRemoto implements Controlador {
    private int volume;
    private boolean tocando;
    private boolean ligado;

    public ControlRemoto() {
        this.volume = 50;
        this.tocando = false;
        this.ligado = false;
    }

    private int getVolume() {
        return volume;
    }

    private void setVolume(int volume) {
        this.volume = volume;
    }

    private boolean getTocando() {
        return tocando;
    }

    private void setTocando(boolean tocando) {
        this.tocando = tocando;
    }

    private boolean getLigado() {
        return ligado;
    }

    private void setLigado(boolean ligado) {
        this.ligado = ligado;
    }

    @Override
    public void ligar() {
        this.setLigado(true);
    }

    @Override
    public void desligar() {
         this.setLigado(true);
    }

    @Override
    public void abrirMenu() {
        System.out.println("Está ligado?"+this.getLigado());
        System.out.println("Está tocando?"+this.getTocando());
        System.out.print("Volume: "+this.getVolume());
        for(int i = 0;i<=this.getVolume();i+=10){
            System.out.print("|");
        }
        System.out.println();
    }

    @Override
    public void fecharMenu() {
        System.out.println("Fechando menu.");
    }

    @Override
    public void aumentar() {
        if(this.getLigado() == true){
            this.setVolume(this.getVolume()+5);
        }
    }

    @Override
    public void abaixar() {
        if(this.getLigado()==true){
            this.setVolume(this.getVolume()-5);
        }
    }

    @Override
    public void ligarMudo() {
        if(this.getLigado()==true && this.getVolume()>0){
            this.setVolume(0);
        }
    }

    @Override
    public void desligarMudo() {
        if(this.getLigado()==true&&this.getVolume()==0){
            this.setVolume(50);
    }
    }

    @Override
    public void play() {
        if(this.getLigado()==true && this.getTocando()==false){
            this.setTocando(true);
    }
    }
    @Override
    public void pause() {
        if(this.getLigado()==true&&this.getTocando()==true){
            this.setTocando(false);
                    
        }
            
    }
   
}