
package controle;


public class Controle {

  
    public static void main(String[] args) {
      ControlRemoto c = new ControlRemoto();
      c.ligar();
      c.ligarMudo();
      c.desligarMudo();
      c.aumentar();
      c.aumentar();
      c.aumentar();
      c.aumentar();
      c.abrirMenu();
    }
    
}
