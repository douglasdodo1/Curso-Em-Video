
package criacaodejanela;
import javax.swing.JOptionPane;

public class CriacaoDeJanela {

    
    public static void main(String[] args) {
        int n,s=0;
        int contador = 0;
        int cpar = 0;
        int cimpar = 0;
        int vm = 0;
        int media = 0;
        int tv;
        
        do{
        n = Integer.parseInt(JOptionPane.showInputDialog(null,
          "<html>Informe um número: <br><em>(valor 0 imterrompe)</em></html>"));
        s+=n;
        contador++;
        if(n%2==0){
            cpar++;
        }
        if(n>=99){
            vm++;
        }
        
        if(n%2!=0){
            cimpar++;
        }
        tv = contador;
        }
        while(n != 0);
        tv--;
        media = s/tv;
        JOptionPane.showMessageDialog(null,
            "<html>Resultado final<hr>"+ "<br>Somatório vale: "+s+ 
            "<br>Total de valores digitados:"+(contador-1)+
            "<br>Total de pares: "+(cpar-1)+
            "<br>Total de impares: "+cimpar+
            "<br>Valores acima de 100: "+vm+
            "<br>Média aritmética: "+media+
            "</html>");
            
               
    }
    
}
