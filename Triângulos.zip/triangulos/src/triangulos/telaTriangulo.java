
package triangulos;


public class telaTriangulo extends javax.swing.JFrame {

    
    public telaTriangulo() {
        initComponents();
        lblVA.setText(Integer.toString(sliA.getValue()));
        lblVB.setText(Integer.toString(sliB.getValue()));
        lblVC.setText(Integer.toString(sliC.getValue()));
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        sliB = new javax.swing.JSlider();
        sliA = new javax.swing.JSlider();
        sliC = new javax.swing.JSlider();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        btnClick = new javax.swing.JButton();
        lblTipo = new javax.swing.JLabel();
        lblFormacao = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        lblVC = new javax.swing.JLabel();
        lblVA = new javax.swing.JLabel();
        lblVB = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/triangulo.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 50, 123, 91));

        sliB.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliBStateChanged(evt);
            }
        });
        getContentPane().add(sliB, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 87, -1, -1));

        sliA.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliAStateChanged(evt);
            }
        });
        getContentPane().add(sliA, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 55, -1, -1));

        sliC.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliCStateChanged(evt);
            }
        });
        getContentPane().add(sliC, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 122, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("A");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 52, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("B");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 84, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setText("c");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(13, 119, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 0, 51));
        jLabel5.setText("c");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 140, 10, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 0, 51));
        jLabel6.setText("B");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 80, 10, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 0, 51));
        jLabel7.setText("A");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 80, 10, -1));

        btnClick.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnClick.setText("Verificar");
        btnClick.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClickActionPerformed(evt);
            }
        });
        getContentPane().add(btnClick, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, -1, -1));

        lblTipo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblTipo.setText("jLabel8");
        getContentPane().add(lblTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 250, 400, -1));

        lblFormacao.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblFormacao.setText("jLabel8");
        getContentPane().add(lblFormacao, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 210, 400, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("Lei de formação de triângulos");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 10, 250, -1));

        lblVC.setText("000");
        getContentPane().add(lblVC, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, -1, -1));

        lblVA.setText("000");
        getContentPane().add(lblVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 60, -1, -1));

        lblVB.setText("000");
        getContentPane().add(lblVB, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnClickActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClickActionPerformed
        int A = sliA.getValue();
        int B = sliB.getValue();
        int C = sliC.getValue();
        int BC = B-C;
        int AC = A-C;
        int AB = A-B;
        AC = AC<0? AC*-1:AC;
        BC = BC<0? BC*-1:BC;
        AB = AB<0? AB*-1:AB;
        String Equilatero= "Triângulo equilatero.";
        String Escaleno = "Triângulo escaleno.";
        String isosceles = "Triângulo isosceles."; 
        boolean confirmacao = false;
        String tipo = "0";
       
       
        
        
        if((BC) < A && A < (B+C)){
            lblFormacao.setText("Forma um triângulo.");
            confirmacao = true;
        }
        else if (AC < B && B < A + C){
            lblFormacao.setText("Forma um Triângulo.");
            confirmacao = true;
        }
        else if (AB < C && C < A + B){
            lblFormacao.setText("Forma um Triângulo.");
        }
        else{
            lblFormacao.setText("Não forma um Triângulo.");
            confirmacao = false;
            lblTipo.setText("");
             }
        
        if(confirmacao == true){
            if(A==B&&A==C){
                lblTipo.setText("Triângulo equilatero.");
            }
            else if(A==B && A!=C||A==C && A!=B || B == C && B!=A){
                lblTipo.setText("Triângulo isosceles.");
            }
            else{
                lblTipo.setText("Triângulo escaleno");
            
            }
        }
    }//GEN-LAST:event_btnClickActionPerformed

    private void sliAStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliAStateChanged
        lblVA.setText(Integer.toString(sliA.getValue()));
    }//GEN-LAST:event_sliAStateChanged

    private void sliBStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliBStateChanged
         lblVB.setText(Integer.toString(sliB.getValue()));
    }//GEN-LAST:event_sliBStateChanged

    private void sliCStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliCStateChanged
        lblVC.setText(Integer.toString(sliC.getValue()));
    }//GEN-LAST:event_sliCStateChanged

    
    public static void main(String args[]) {
        
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(telaTriangulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(telaTriangulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(telaTriangulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(telaTriangulo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new telaTriangulo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnClick;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel lblFormacao;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JLabel lblVA;
    private javax.swing.JLabel lblVB;
    private javax.swing.JLabel lblVC;
    private javax.swing.JSlider sliA;
    private javax.swing.JSlider sliB;
    private javax.swing.JSlider sliC;
    // End of variables declaration//GEN-END:variables
}
