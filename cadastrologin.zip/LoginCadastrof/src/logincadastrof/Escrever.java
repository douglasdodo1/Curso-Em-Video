package logincadastrof;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author carva
 */
public class Escrever {
    public static boolean escrever(String caminho, String texto){
        try {
            FileWriter arq  = new FileWriter(caminho,true);
            BufferedWriter armazenado = new BufferedWriter(arq);
            PrintWriter gravarArq = new PrintWriter(armazenado);
            gravarArq.println(texto);
            gravarArq.close();
            return true;
            
        } catch (IOException ex) {
            Logger.getLogger(Escrever.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    
}
}
