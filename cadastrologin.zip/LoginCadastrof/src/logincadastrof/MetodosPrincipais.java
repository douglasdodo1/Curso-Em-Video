package logincadastrof;

/**
 *
 * @author carva
 */
public interface MetodosPrincipais {
    
    public abstract void mostrar();
    public abstract void fechar();
}
