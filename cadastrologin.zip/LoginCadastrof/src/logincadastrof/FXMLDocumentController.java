package logincadastrof;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 *
 * @author carva
 */
public class FXMLDocumentController implements Initializable {
    
    LoginCadastrof l = new LoginCadastrof();
    Cadastro c = new Cadastro();
    Separador s = new Separador();
    Principal p = new Principal();
    
    @FXML
    private Label label;
    @FXML
    private Button btnCadastro;
    @FXML
    private Label lblIncorreto;
    @FXML
    private Button btnEntrar;
    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField pfSenha;

    
    
    @FXML
    private void CadastroPressionado(ActionEvent event) {
       c.mostrar();
       
    }
     @FXML
    private void EntrarPressionado(ActionEvent event) {
       String arq = "dados.txt";
       String leitura = s.ler(arq);
       int contador = 0;
       
         if (leitura.contains(txtUsuario.getText())) {
             if(txtUsuario.getText().isEmpty()==false){
             lblIncorreto.setVisible(false);
             contador++;//contador = 1
             }
         } else {
             lblIncorreto.setVisible(true);
         }
         if (leitura.contains(pfSenha.getText())) {
             if(pfSenha.getText().isEmpty()==false){
             lblIncorreto.setVisible(false);
             contador++;//contador = 2;
             }
         } else {
             lblIncorreto.setVisible(true);
         }
        
            if (contador==2) {
                p.mostrar();
                contador = 0;
            } else {
                contador=0;
        }
      
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
      lblIncorreto.setVisible(false);
    }    
    
}
