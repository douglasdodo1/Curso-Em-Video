package logincadastrof;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author carva
 */
public class Separador {
   public static String ler(String caminho){
       String conteudo = "";
      try{
          FileReader arq = new FileReader(caminho);
          BufferedReader lerArq = new BufferedReader(arq);
          String linha = "";
          try{
              linha = lerArq.readLine();
              while(linha!=null){
                  conteudo +=linha;
                  linha = lerArq.readLine();
              }
          }
          catch(IOException ex){
              System.out.println("erro");
          }
      } 
      catch(FileNotFoundException ex){
          System.out.println("nao encontrado");
      }
      
       if (conteudo.contains("erro")) {
           return "";
       } else {
           return conteudo;
       }
      
      
   }
}
