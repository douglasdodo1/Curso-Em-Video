
package logincadastrof;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author carva
 */

public class CadastroController implements Initializable {
    
   
    @FXML
    private Button btnFecharc;
    @FXML
    private Button btnCadastrar;
    @FXML
    private TextField txtUsuario;
    @FXML
    private PasswordField pfSenha;
    @FXML 
    private PasswordField pfCsenha;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtCemail;
    @FXML
    private Label checkLogin;
    @FXML
    private Label checkSenha;
    @FXML
    private Label checkCsenha;
    @FXML
    private Label checkEmail;
    @FXML
    private Label checkCemail;
    @FXML

     
    Cadastro c = new Cadastro();
    Escrever e = new Escrever();
    Separador s = new Separador();
  
    
     @FXML
      private void CadastroPressionado(ActionEvent event) {
      String arq = "dados.txt";
      String leitura = s.ler("dados.txt");
      int contador = 0;
         
      if(leitura.contains(txtUsuario.getText())){
          checkLogin.setVisible(true);
      }
      else{
          contador++;//contador = 1
          checkLogin.setVisible(false);     
      }
          
          if (pfSenha.getText().equals(pfCsenha.getText())) {
             contador++;//contador = 2
             
             checkCsenha.setVisible(false);
         } 
          else {
              checkCsenha.setVisible(true);
         }            
    
       if (leitura.contains(txtEmail.getText())) {
              
              checkEmail.setVisible(true);
          
       }
       
          else {
           checkEmail.setVisible(false);
       }
              if (txtEmail.getText().equals(txtCemail.getText())) {
                  if(txtEmail.getText().contains("@gmail.com")){
                  contador++;// contador = 3;;
                  checkCemail.setVisible(false);
                  }
                  
          }
              else{
                  
                  checkCemail.setVisible(true);
              }
              
         if (contador == 3) {
             System.out.println("cadastrado com sucesso");
             e.escrever("dados.txt","login:"+txtUsuario.getText()+","+
             "senha:"+pfSenha.getText()+","+"Email:"+txtEmail.getText()+".");
         } else {
             contador = 0;
         }
         System.out.println(contador);
         
         
    }
      
      
     @FXML
    private void FechadoPressionado(ActionEvent event) {
       c.fechar();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       checkLogin.setVisible(false);
       checkSenha.setVisible(false);
       checkCsenha.setVisible(false);
       checkEmail.setVisible(false);
       checkCemail.setVisible(false);
    }
    
}


