
package horadosistema;
import java.util.Date;

public class HoraDoSistema { 
    public static void main(String[] args) {
      Date relogio = new Date();
        System.out.print("horário do sistema: ");
        System.out.println(relogio. toString());
    }
    
}
