package ultracombat;

public class UltraCombat {

    public static void main(String[] args) {
        
        Lutador l[] = new Lutador[6];
                
        l[0]= new  Lutador("Pretty boy","Fraça",31,1.75f,69.9f,11,2,1);
        l[1] = new Lutador("Putscript","Brasil",29,1.68f,62.8f,14,2,3);
        Luta UEC1 = new Luta();
        UEC1.marcarLuta(l[0], l[1]);
        UEC1.lutar();
        l[0].status();
        l[1].status();

}
}
