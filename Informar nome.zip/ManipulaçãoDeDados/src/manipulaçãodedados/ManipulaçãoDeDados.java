
package manipulaçãodedados;
import java.util.Scanner;

public class ManipulaçãoDeDados {


    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    String nome = teclado.nextLine();
        System.out.printf("A nome: %s \n ", nome );
    }
    
}
