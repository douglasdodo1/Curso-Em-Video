package banco;

public class Banco {

    public static void main(String[] args) {
      ContaBanco p1 = new ContaBanco();
      p1.setnumConta(1111);
      p1.setDono("Jubileu");
      p1.abrirconta("CC");
      p1.depositar(100);
      p1.estadoAtual();
 
      
      ContaBanco p2 = new ContaBanco();
      p2.setnumConta(2222);
      p2.setDono("Jubileide");
      p2.abrirconta("CP");
      p2.depositar(500);
      p2.estadoAtual();
      p2.sacar(650);
      p2.fecharconta();
      p2.estadoAtual();
      
    }
    
}
