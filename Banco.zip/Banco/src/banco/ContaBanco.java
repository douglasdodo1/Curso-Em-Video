package banco;

public class ContaBanco {
    public int NumConta;
    protected String Tipo;
    private String Dono;
    private float Saldo;
    private boolean Status;
    
    public void estadoAtual(){
        if(this.getTipo()!="CC" && this.getTipo()!="CP"){
            System.out.println("ERRO AO ABRIR CONTA");
        }
        else{
        System.out.println("-------------------------------------");
        System.out.println("conta:"+this.getNumConta());
        System.out.println("Tipo:"+this.getTipo());
        System.out.println("Dono:"+this.getDono());
        System.out.println("Saldo:"+this.getSaldo());
        System.out.println("Status da conta:"+this.getStatus());
        System.out.println("-------------------------------------");
    }
    }
    
    public void  abrirconta(String t){
        if(this.getStatus() == false){
            this.setTipo(t);
            this.setStatus(true);
        if("CC".equals(t)){
            this.setSaldo(50);
        }
        else if("CP".equals(t)){
            this.setSaldo(150);
        }
            
        }
    }
    public void fecharconta(){
        if(this.getStatus() == true){
            if(Saldo == 0){
                this.setStatus(false);
            }
        }
    }
    
    public void depositar(float v){
        if(this.getStatus()==true){
            this.setSaldo(this.getSaldo() + v);
        }
    }
    public void sacar(float v){
        if(this.getStatus()==true&& this.getSaldo()>=v){
            this.setSaldo(this.getSaldo()-v);
        }
    }
    
    public void pagarmensal(){
        int V = 0;
        if (this.getTipo() == "CC") {
            V = 12;
        } else if(this.getTipo() == "CP") {
            V = 20;
        }
        if(this.getStatus() == true){
            this.setSaldo(this.getSaldo() - V);
        }
    }
    
    public void setnumConta(int n){
        this.NumConta = n;
    }
    public int getNumConta(){
        return this.NumConta;
    }
    
    public void setTipo(String T){
        this.Tipo = T;
    }
    public String getTipo(){
        return this.Tipo;
    }
    
    public void setDono(String D){
        this.Dono = D;
    }
    
    public String getDono(){
        return this.Dono;
    }
    
    public void setSaldo(float S){
        this.Saldo = S;
    }
    
    public float getSaldo(){
        return this.Saldo;
    }
    
    public void setStatus(boolean ss){
        this.Status = ss;
    }
    
    public boolean getStatus(){
        return this.Status;
    }
    
    public ContaBanco(){
        this.setSaldo(0f);
        this.setStatus(false);
                
    }
}